from django.urls import path
from . import views

urlpatterns =[
    path ('',views.index,name='index'),
    path('login',views.login,name='login'),
    path('dashboard',views.dashboard,name='dashboard'),
    path('add_car',views.add_car,name='add_car'),
    path('contact',views.contact,name='contact'),
    path('edit_car',views.edit_car,name='edit_car'),
    path('forgot-password',views.forgot_password,name='forgot-password'),
    path('gallary',views.gallary,name='gallary'),
    path('news',views.news,name='news'),
    path('oview',views.orview,name='orview'),
    path('payment',views.payment,name='payment'),
    path('register',views.register,name='register'),
    path('report',views.report,name='report'),
    path('survey',views.survey,name='survey'),
    path('testimonal',views.testimonal,name='testimonal'),
    path('userdata',views.userdata,name='userdata'),
    path('utilities-animation',views.utilities_animation,name='utilities-animation'),
    path('utilities-border',views.utilities_border,name='utilities-border'),
    path('utilities-color',views.utilities_color,name='utilities-color'),
    path('register_form_submission',views.register_form_submission,name='register_form_submission')
]