from django.db import models

# Create your models here.
class reg1(models.Model):
    first_name=models.CharField(max_length=250)
    last_password=models.CharField(max_length=15)
    mail1=models.EmailField()
    password=models.CharField(max_length=100)