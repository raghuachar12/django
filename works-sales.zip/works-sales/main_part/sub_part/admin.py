from django.contrib import admin

# Register your models here.

from . models import reg1
admin.site.register(reg1)