from email import message
from unicodedata import name
from django.shortcuts import render
from . models import reg1
from django.contrib import messages
# Create your views here.
def index(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')
    
def dashboard(request):
    return render(request, 'dashboard.html')

def add_car(request):
    return render(request, 'add_car.html')

def contact(request):
    return render(request, 'contact.html')

def edit_car(request):
    return render(request, 'edit_car.html')

def forgot_password(request):
    return render(request, 'forgot-password.html')

def gallary(request):
    return render(request, 'gallary.html')

def news(request):
    return render(request, 'news.html')

def orview(request):
    return render(request, 'orview.html')

def payment(request):
    return render(request, 'payment.html')

def register(request):
    return render(request, 'register.html')

def register_form_submission(request):
    if request.method == 'POST':

        ex1=reg1(first_name=request.POST.get('first_name'),
                    last_name=request.POST.get('last_name'),
                    mail1=request.POST.get('mail1'),
                    password=request.POST.get('password'))
        ex1.save()
        messages.error(request,'sucessfully registered',extra_tags='sucess')
        return render(request, 'login.html')

    else:
        return render(request, 'register.html')

def report(request):
    return render(request, 'report.html')

def survey(request):
    return render(request, 'survey.html')

def testimonal(request):
    return render(request, 'testimonal.html')

def userdata(request):
    return render(request, 'userdata.html')

def utilities_animation(request):
    return render(request, 'utilities-animation.html')

def utilities_border(request):
    return render(request, 'utilities-border.html')

def utilities_color(request):
    return render(request, 'utilities-color.html')






















